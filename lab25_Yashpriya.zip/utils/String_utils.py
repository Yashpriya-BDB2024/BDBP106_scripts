def convert_upper(str):
    return str.upper()
def convert_lower(str):
    return str.lower()
def concatenate(str1, str2):
    return str1+str2
